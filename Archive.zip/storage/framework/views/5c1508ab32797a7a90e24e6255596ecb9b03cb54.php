<div class="comment-card">
    <div class="card-body">
        <h3><a href="/users/profile/<?php echo e($comment->user->id); ?>"><?php echo e($comment->user->name); ?></a></h3><h5> <?php echo e($comment->created_at->diffForHumans()); ?></h5>
        <h4><?php echo e($comment->body); ?></h4>
        <?php if(Auth::id() == $comment->user_id): ?>
        <hr />
        <a href="/comments/<?php echo e($comment->id); ?>/edit" class="btn btn-info">Edit</a> |
        <?php endif; ?>
        <?php if(Auth::id() == $comment->user_id): ?>
        <form action="/comments/<?php echo e($comment->id); ?>" method="POST" class="d-inline">
            <?php echo e(method_field('DELETE')); ?>

            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-link">Delete</button>
        <?php endif; ?>
        </form>
    </div>
</div>
<?php /**PATH /home/vagrant/code/Tweeter/resources/views/comments/_comment.blade.php ENDPATH**/ ?>