        <?php $__env->startSection('content'); ?>
            <div class="container">
                <form action="/tweets/<?php echo e($tweet->id); ?>" method="POST">
                    <?php echo e(method_field('PUT')); ?>

                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <textarea name="body" class="form-control" value="body"><?php echo e($tweet->body); ?></textarea>
                    </div>
                    <button type="submit" class="btn btn-dark">Save Changes</button>
                </form>
            </div>
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/Tweeter/resources/views/tweets/edit.blade.php ENDPATH**/ ?>