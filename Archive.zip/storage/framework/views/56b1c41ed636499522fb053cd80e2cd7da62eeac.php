<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col">
            <?php echo $__env->make('tweets._tweet', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <br />
            <a href="/tweets/" class="btn btn-primary">back</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/Tweeter/resources/views/tweets/show.blade.php ENDPATH**/ ?>