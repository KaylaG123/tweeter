
    <p>Copyright &copy; 2019-Tweeter. All rights reserved.
    </p>
<?php /**PATH /home/vagrant/code/Tweeter/resources/views/layout/_footer.blade.php ENDPATH**/ ?>