    <?php $__env->startSection('content'); ?>
        <div class="container">
            <div class="flash-message">
                <?php if(Session::has('message')): ?>
                    <p><?php echo e(Session('message')); ?></p>
                <?php endif; ?>
            </div>
            <form action="/tweets" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <textarea name="body" class="form-control" placeholder="What's on your mind..."></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Tweet</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/Tweeter/resources/views/tweets/create.blade.php ENDPATH**/ ?>