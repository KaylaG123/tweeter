<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <meta name="_token" content="<?php echo e(csrf_token()); ?>" />
        <title>Tweeter</title>
        <link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <link rel="stylesheet" href="/css/app.css">
    </head>
    <body>
        <div class="page-wrapper">
            <div class="header-wrapper">
                <?php echo $__env->make('layout._header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="navbar-wrapper">
                <?php echo $__env->make('layout._navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="content-wrapper">

            <?php echo $__env->yieldContent('content'); ?>
            </div>
            <div class="footer-wrapper">
                <?php echo $__env->make('layout._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
</div>
    <script src="/js/app.js"></script>

    </body>
</html>
<?php /**PATH /home/vagrant/code/Tweeter/resources/views/layout/main.blade.php ENDPATH**/ ?>