<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <form action="/users/profile/<?php echo e($profile->user->id); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo e(method_field('PUT')); ?>

                    <div class="form-group">
                        <label for="first_name">First Name</label>
                        <input type="text" name="first_name" class="form-control" value="<?php echo e($profile->user->name); ?>"/>
                    </div>
                    <div class="form-group">
                        <label for="location">Location</label>
                        <input type="text" name="location" class="form-control" value="<?php echo e($profile->location); ?>"/>
                    </div>
                    <div class="form-group">
                        <label for="birthday">Birthday</label>
                        <input type="text" name="birthday" class="form-control" value="<?php echo e($profile->birthday); ?>"/>
                    </div>
                    <div class="form-group">
                        <label for="bio">Bio</label>
                        <input type="text" name="bio" class="form-control" value="<?php echo e($profile->bio); ?>"/>
                    </div>
                    <div class="form-group">
                        <label for="image">Image (only .jpg)</label>
                        <input type="file" name="image" class="form-control"/>
                    </div>
                    <button type="submit" class="btn btn-primary">Save Account</button>
                    <?php echo csrf_field(); ?>
                </form>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/Tweeter/resources/views/profile/edit.blade.php ENDPATH**/ ?>