<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <img class="card-img-top" src="/storage/avatars/<?php echo e($user->profile->avatar); ?>" alt="Card image">
                <div class="card-body">
                    <h4 class="card-title"><a href="/users/profile/<?php echo e($user->id); ?>"><?php echo e($user->name); ?></a></h4>
                    <h4 class="card-title"><?php echo e($user->profile->location); ?></h4>
                    <h4 class="card-title"><?php echo e($user->profile->birthday); ?></h4>
                    <h4 class="card-title"><?php echo e($user->profile->bio); ?></h4>
                    <p class="mb-2">
                        <h3>Following: <span class="badge badge-primary"><?php echo e($user->followings()->get()->count()); ?></span></h3>
                        <h3>Followers: <span class="badge badge-primary"><?php echo e($user->followers()->get()->count()); ?></span></h3>
                    </p>
                    <button class="btn btn-primary follow"  data-id="<?php echo e($user->id); ?>">
                        <strong>
                            <?php if(auth()->user()->isFollowing($user)): ?>
                            UnFollow
                            <?php else: ?>
                            Follow
                            <?php endif; ?>
                        </strong>
                    </button>
                    <?php if(Auth::id() == $user->profile->user_id): ?>
                    <a href="/users/profile/<?php echo e($user->id); ?>/edit" class="btn btn-dark">Edit Profile</a>
                    <?php endif; ?>
                </div>
            </div>
            <br />
            <div class="panel-body">
                <h2 class="create">What's on your mind?
                    <a href="/tweets/create" class="btn btn-primary">Tweet</a>
                </h2>
            </div>
            <br />
            <div>
                <h2><?php echo e($user->name); ?>'s Latest Tweets:</h2>

                <?php $__currentLoopData = $user->tweets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tweet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- <h2><?php echo e($tweet->user->name); ?></h2>
                <h3><?php echo e($tweet->body); ?></h4> -->
                    <?php echo $__env->make('tweets._tweet', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/Tweeter/resources/views/profile/index.blade.php ENDPATH**/ ?>