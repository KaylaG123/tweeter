<?php $__env->startSection('content'); ?>

<h1><?php echo e($tweet->body); ?></h1>
<hr />
    <h2>Comment</h2>
    <form action="/comments" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <textarea name="body" class="form-control"></textarea>
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-primary">Add comment</button>
        </div>

        <input type="hidden" name="tweet_id" value="<?php echo e($tweet_id); ?>" />
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/Tweeter/resources/views/comments/create.blade.php ENDPATH**/ ?>