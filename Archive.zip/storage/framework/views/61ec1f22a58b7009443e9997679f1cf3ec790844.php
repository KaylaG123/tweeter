<div class="sidebar-wrapper">
    
</div>
<?php /**PATH /home/vagrant/code/Tweeter/resources/views/layout/_sidebar.blade.php ENDPATH**/ ?>