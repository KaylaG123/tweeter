<article>
    <div class="list-group-item">
        <div class="row">
            <div class="col">
                <h1 class="body">
                    <div><a href="/users/profile/<?php echo e($tweet->user->id); ?>"><?php echo e($tweet->user->name); ?></a></div>
                <h1>
                <a href="/tweets/<?php echo e($tweet->id); ?>"><?php echo e($tweet->body); ?></a>
                <div>
                    <?php $__currentLoopData = $tweet->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('comments._comment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                    <?php if(Auth::id() == $tweet->user_id): ?>
                        <a href="/tweets/<?php echo e($tweet->id); ?>/edit" class="btn btn-primary">Edit</a>
                    <?php endif; ?>
                <div>
                    <a href="/comments/create/<?php echo e($tweet->id); ?>" class="btn btn-primary">Comment</a>
                </div>
                <a href="/tweets/<?php echo e($tweet->id); ?>/like" class="btn btn-link">Like</a>
                (<?php echo e($tweet->likes()->count()); ?>)
            </div>
             <?php if(Auth::id() == $tweet->user_id): ?>

            <div class="col-2 d-flex align-items-center justify-content-end">
                <form action="/tweets/<?php echo e($tweet->id); ?>" method="POST" class="form-inline">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('DELETE')); ?>

                    <button type="submit" class="close">&times;</button>
                </form>
            </div>
            <?php endif; ?>
        </div>
    </div>
</article>
<?php /**PATH /home/vagrant/code/Tweeter/resources/views/tweets/_tweet.blade.php ENDPATH**/ ?>