<?php $__env->startSection('content'); ?>
<script src="<?php echo e(asset('public/js/custom.js')); ?>" defer></script>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">List of Users</div>

                <div class="card-body">
                    <div class="row pl-5">
                        <?php echo $__env->make('users.userList', ['users' => $users], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/Tweeter/resources/views/users/users.blade.php ENDPATH**/ ?>