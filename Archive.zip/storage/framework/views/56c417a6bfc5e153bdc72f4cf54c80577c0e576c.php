<?php $__env->startSection('content'); ?>

    <h1>Edit comment</h1>

    <form action="/comments/<?php echo e($comment->id); ?>" method="POST">
        <?php echo e(method_field('PUT')); ?>

        <?php echo csrf_field(); ?>
        <div class="form-group">
            <textarea name="body" class="form-control"><?php echo e($comment->body); ?></textarea>
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-primary">Save comment</button>
        </div>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/Tweeter/resources/views/comments/edit.blade.php ENDPATH**/ ?>