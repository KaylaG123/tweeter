<!--https://investmentnovel.com/how-to-create-follow-unfollow-functionality-in-laravel/-->
<!-- https://itsolutionstuff.com/post/laravel-5-follow-unfollow-system-exampleexample.html -->



<?php $__env->startSection('content'); ?>
    <div class="col">
    <h2>Connect with interesting people</h2>
    <br>
    <div class="row">
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(auth()->user()->id !== $user->id): ?>
        <div class="card" style="width:250px">
            <img class="card-img-top" src="/images/<?php echo e($user->profile->avatar); ?>" alt="Card image">
            <div class="card-body">
                <h4 class="card-title"><a href="/users/profile/<?php echo e($user->id); ?>"><?php echo e($user->name); ?></a></h4>
                <h4 class="card-title"><?php echo e($user->profile->location); ?></h4>
                <h4 class="card-title"><?php echo e($user->profile->birthday); ?></h4>
                <h4 class="card-title"><?php echo e($user->profile->bio); ?></h4>
                <h4 class="mb-2">
                    <h4>Following: <span class="badge badge-primary"><?php echo e($user->followings()->get()->count()); ?></span></h4>
                    <h4>Followers: <span class="badge badge-primary"><?php echo e($user->followers()->get()->count()); ?></span></h4>
                </p>
                <button class="btn btn-primary follow"  data-id="<?php echo e($user->id); ?>">
                    <strong>
                        <?php if(auth()->user()->isFollowing($user)): ?>
                        UnFollow
                        <?php else: ?>
                        Follow
                        <?php endif; ?>
                    </strong>
                </button>
            </div>
        </div>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<div class="col-md-10">
    <div class="row justify-content-end">
        <a href="/tweets" class="btn btn-primary">Next</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/Tweeter/resources/views/users/index.blade.php ENDPATH**/ ?>