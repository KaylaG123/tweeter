
    <h1 class="title">Tweeter</h1>




<!-- enter profile picture top right -->
<?php /**PATH /home/vagrant/code/Tweeter/resources/views/layout/_header.blade.php ENDPATH**/ ?>